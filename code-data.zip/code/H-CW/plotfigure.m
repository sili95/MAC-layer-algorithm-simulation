%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����ͼչʾ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x=zeros(1,22);
for i=1:22
    x(1,i) = 250/((230-10*i)/2+10)*7.5*4*0.001*4*1024*4096;
end
figure(1);
plot(x,BEBDelay,'r:*');
xlabel('load/bps');
ylabel('Delayaverage/s');
title('Delay average');
hold on
figure(2)
plot(x,BEBDelayMax,'r:*');
xlabel('load/bps');
ylabel('Delaymax/s');
title('Delaymax');
hold on
figure(3);
plot(x,BEBP,'r:*');
xlabel('load/bps');
ylabel('Probability');
title('Probability of frame success transmission');
hold on
figure(4)
plot(x,250*BEBThroughput,'r:*');
xlabel('load/bps');
ylabel('Throughput/bps');
title('the throughput of satellite network');
hold on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����ͼչʾ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1);
plot(x,HDelay,'g-.v');
xlabel('load/bps');
ylabel('Delayaverage/s');
title('Delay average');
figure(2)
plot(x,HDelayMax,'g-.v');
xlabel('load/bps');
ylabel('Delaymax/s');
title('Delaymax');
figure(3);
plot(x,HP,'g-.v');
xlabel('load/bps');
ylabel('Probability');
title('Probability of frame success transmission');
figure(4)
plot(x,250*HThroughput,'g-.v');
xlabel('load/bps');
ylabel('Throughput/bps');
title('the throughput of satellite network');


