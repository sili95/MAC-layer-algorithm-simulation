clear all;
close all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%������ڵ������ϵͳ���ܵ�Ӱ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delay1 = zeros(1,20);
delay2 = zeros(1,20);
delay3 = zeros(1,20);
DELAY = zeros(1,20);
delayMax1 = zeros(1,20);
delayMax2 = zeros(1,20);
delayMax3 = zeros(1,20);
DELAYMAX = zeros(1,20);
p1 = zeros(1,20);
p2 = zeros(1,20);
p3 = zeros(1,20);
P = zeros(1,20);
throughput1 = zeros(1,20);
throughput2 = zeros(1,20);
throughput3 = zeros(1,20);
THROUGHPUT = zeros(1,20);
for i=16
    [delay1(i),delayMax1(i),p1(i),throughput1(i)] = CsmacaBEB(220-10*i);
    [delay2(i),delayMax2(i),p2(i),throughput2(i)] = CsmacaBEB(220-10*i);
    [delay3(i),delayMax3(i),p3(i),throughput3(i)] = CsmacaBEB(220-10*i);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
DELAY = (delay1+delay2+delay3)/3;
DELAYMAX = (delayMax1+delayMax2+delayMax3)/3;
P = (p1+p2+p3)/3;
THROUGHPUT = (throughput1+throughput2+throughput3)/3;
%%%%%%%%%%%%%
x = 1:20;
figure(1);
plot(x,DELAY);
title('The average time delay of the network');
ylabel('delay/s');
figure(2)
plot(x,DELAYMAX);
title('The maximum time delay of the network');
ylabel('delay/s');
figure(3)
plot(x,P);
title('Probability of frame success transmission');
ylabel('probability');
figure(4)
plot(x,THROUGHPUT);
title('The throughput of the network');
ylabel('throughput/bps');
