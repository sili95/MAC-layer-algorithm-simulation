%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SetBackoffTime�������ܣ������˱ܴ��������˱�ʱ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ret = SetBackoffTimeH(BackoffPutIn)
Net_Busy_Detect_Time = 0.5;
DTETURN = 10;
CountBackoff = BackoffPutIn(1,1);
NumberNodes = BackoffPutIn(1,4);
load = BackoffPutIn(1,2);
FramePriority = BackoffPutIn(1,3);
CWmax = 2*ceil(BackoffPutIn(1,5));
if load < 160
    TL = 0.5;
else if load < 240
    TL = 1;
    else 
        TL = 1.5;
    end
end
ADJ_NS = max((ceil(NumberNodes*TL)),1);
USIZE = 0.25*ADJ_NS;
PSIZE = 0.25*ADJ_NS;
RSIZE = 0.5*ADJ_NS;
Urgent_MIN = 0;
Urgent_MAX = USIZE+1;
Priority_MIN = Urgent_MAX +1;
Priority_MAX = Priority_MIN + PSIZE + 1;
Routine_MIN = Priority_MAX +1;
Routine_MAX = Routine_MIN + RSIZE + 1;
switch FramePriority
    case 1
        MAXNumber = Urgent_MAX;
        MINNUmber = Urgent_MIN;
        F = ceil(MINNUmber + rand()* (MAXNumber - MINNUmber)+CountBackoff);
    case 2
        MAXNumber = Priority_MAX;
        MINNUmber = Priority_MIN;
        F = ceil(MINNUmber + rand()* (MAXNumber - MINNUmber)+CountBackoff);
    case 3
        MAXNumber = Routine_MAX;
        MINNUmber = Routine_MIN;
        F = ceil(MINNUmber + rand()* (MAXNumber - MINNUmber)+CountBackoff*(MAXNumber+1-MINNUmber));
end
NAD = ceil(F * Net_Busy_Detect_Time + max(0, F-1) * DTETURN);
if NAD>CWmax
    NAD = CWmax;
end
t = randperm(NAD);                                                       %���˱�ʱ�������ֵ��Χ�������˱�ʱ������
while t(1)==0
    t = randperm(NAD);
end
BackoffTime = t(1); 
ret = BackoffTime;                                                         %��������˱�ʱ��
end