%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����BEB�㷨�ڵ�仯��������ܱ仯ͼ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%������ڵ������ϵͳ���ܵ�Ӱ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����ͼչʾ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure (1)
set(gcf,'unit','centimeters','position',[2,2,8.8,7]);
LE=legend('\red--BEB algorithm','\green--Adaptive BEB algorithm');
set(LE,'FontSize',10,'FontName','Arial san serif');
plot(1:12,BEBDelay,'r:*');
xlabel('Nodes','FontSize',10,'FontName','Arial san serif');
ylabel('Delayaverage (s)','FontSize',10,'FontName','Arial san serif');
%title('Delay average');
hold on
figure (2)
set(gcf,'unit','centimeters','position',[2,2,8.8,7]);
LE=legend('\red--BEB algorithm','\green--Adaptive BEB algorithm');
set(LE,'FontSize',10,'FontName','Arial san serif');
plot(1:12,BEBDelayMax,'r:*');
xlabel('Nodes','FontSize',10,'FontName','Arial san serif');
ylabel('Delaymax (s)','FontSize',10,'FontName','Arial san serif');
%title('Delaymax');
hold on
figure (3)
set(gcf,'unit','centimeters','position',[2,2,8.8,7]);
LE=legend('\red--BEB algorithm','\green--Adaptive BEB algorithm');
set(LE,'FontSize',10,'FontName','Arial san serif');
plot(1:12,BEBP,'r:*');
xlabel('Nodes','FontSize',10,'FontName','Arial san serif');
ylabel('Probability','FontSize',10,'FontName','Arial san serif');
%title('Probability of frame success transmission');
hold on
figure (4)
set(gcf,'unit','centimeters','position',[2,2,8.8,7]);
LE=legend('\red--BEB algorithm','\green--Adaptive BEB algorithm');
set(LE,'FontSize',10,'FontName','Arial san serif');
plot(1:12,BEBThroughput,'r:*');
xlabel('Nodes','FontSize',10,'FontName','Arial san serif');
ylabel('the effective throughput (kbps)','FontSize',10,'FontName','Arial san serif');
%title('The throughput of satellite network');
hold on


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����BEBCW�㷨�ڵ�仯��������ܱ仯ͼ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%������ڵ������ϵͳ���ܵ�Ӱ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%����ͼչʾ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure (1);
plot(1:12,BEBCWDelay,'g-.v');
xlabel('Nodes','FontSize',10,'FontName','Arial san serif');
ylabel('the average of delay (s)','FontSize',10,'FontName','Arial san serif');
%title('Delay average');
figure (2)
plot(1:12,BEBCWDelayMax,'g-.v');
xlabel('Nodes','FontSize',10,'FontName','Arial san serif');
ylabel('the maximum of Delay (s)','FontSize',10,'FontName','Arial san serif');
%title('Delaymax');
figure (3)
plot(1:12,BEBCWP,'g-.v');
xlabel('Nodes','FontSize',10,'FontName','Arial san serif');
ylabel('Probability','FontSize',10,'FontName','Arial san serif');
%title('Probability of frame success transmission');
figure (4)
plot(1:12,BEBCWThroughput,'g-.v');
xlabel('Nodes','FontSize',10,'FontName','Arial san serif');
ylabel('the effective throughput (kbps)','FontSize',10,'FontName','Arial san serif');
%title('The throughput of satellite network');


